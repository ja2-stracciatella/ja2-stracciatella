// Main include header for the MicroIni library

#include <MicroIni/File.hpp>
