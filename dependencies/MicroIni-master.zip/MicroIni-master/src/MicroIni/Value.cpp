#include <MicroIni/Value.hpp>

namespace MicroIni
{

Value::Value(const std::string& value)
 : std::string(value)
{}

} // namespace MicroIni
